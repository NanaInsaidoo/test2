import React from 'react'

function PageNotFound() {
    return (
        <div>
            PAGE NOT FOUND
        </div>
    )
}

export default PageNotFound
