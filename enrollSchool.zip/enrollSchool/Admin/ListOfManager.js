import React from 'react';
import { withStyles, makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import { Grid, Link } from '@material-ui/core';
import Box from '@material-ui/core/Box';


const StyledTableCell = withStyles((theme) => ({
  head: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
  },
  body: {
    fontSize: 14,
  },
  emptyspa:{
    height:"100px",
    width: "20px"

  },
}))(TableCell);

const StyledTableRow = withStyles((theme) => ({
  root: {
    '&:nth-of-type(odd)': {
      backgroundColor: theme.palette.action.hover,
    },
  },
}))(TableRow);

function createData(id, first_Name, last_Name, phone, 
  email,Manage_Type,Accounts,Account_Pending,location) {
  return { id, first_Name, last_Name, phone, 
    email,Manage_Type,Accounts,Account_Pending,location };
}

const rows = [
  createData(' sam', 159, 6.0, 24, 9,"","","","",""),
  createData(' pam', 159, 6.0, 24, 9,"","","","",""),
  createData(' nam', 159, 6.0, 24, 9,"","","","",""),
  createData(' Amoah', 159, 6.0, 24, 9,"","","","",""),
  createData(' Amoah', 159, 6.0, 24, 9,"","","","",""),
  
  createData(' sam', 159, 6.0, 24, 9,"","","","",""),
  createData(' pam', 159, 6.0, 24, 9,"","","","",""),
  createData(' nam', 159, 6.0, 24, 9,"","","","",""),
  createData(' Amoah', 159, 6.0, 24, 9,"","","","",""),
  createData(' Amoah', 159, 6.0, 24, 9,"","","","",""),
  
  createData(' sam', 159, 6.0, 24, 9,"","","","",""),
  createData(' pam', 159, 6.0, 24, 9,"","","","",""),
  createData(' nam', 159, 6.0, 24, 9,"","","","",""),
  createData(' Amoah', 159, 6.0, 24, 9,"","","","",""),
  createData(' Amoah', 159, 6.0, 24, 9,"","","","",""),
  
  createData(' sam', 159, 6.0, 24, 9,"","","","",""),
  createData(' pam', 159, 6.0, 24, 9,"","","","",""),
  createData(' nam', 159, 6.0, 24, 9,"","","","",""),
  createData(' Amoah', 159, 6.0, 24, 9,"","","","",""),
  createData(' Amoah', 159, 6.0, 24, 9,"","","","",""),
  
  createData(' sam', 159, 6.0, 24, 9,"","","","",""),
  createData(' pam', 159, 6.0, 24, 9,"","","","",""),
  createData(' nam', 159, 6.0, 24, 9,"","","","",""),
  createData(' Amoah', 159, 6.0, 24, 9,"","","","",""),
  createData(' Amoah', 159, 6.0, 24, 9,"","","","",""),
  
  createData(' sam', 159, 6.0, 24, 9,"","","","",""),
  createData(' pam', 159, 6.0, 24, 9,"","","","",""),
  createData(' nam', 159, 6.0, 24, 9,"","","","",""),
  createData(' Amoah', 159, 6.0, 24, 9,"","","","",""),
  createData(' Amoah', 159, 6.0, 24, 9,"","","","",""),
  
  createData(' sam', 159, 6.0, 24, 9,"","","","",""),
  createData(' pam', 159, 6.0, 24, 9,"","","","",""),
  createData(' nam', 159, 6.0, 24, 9,"","","","",""),
  createData(' Amoah', 159, 6.0, 24, 9,"","","","",""),
  createData(' Amoah', 159, 6.0, 24, 9,"","","","",""),
  
];

const useStyles = makeStyles({
  table: {
    minWidth: 700,
  },
});

export default function CustomizedTables() {
  const classes = useStyles();

  const jojo = (e) => {
   e.preventDefault()
   console.log("e",e.target.id)
   
  };


  return (
    <div>
       <Grid 
        container
        direction="row"
        justify="center"
        alignItems="center"
       > </Grid>
      <Grid
  container
  direction="row"
  justify="center"
  alignItems="center"
>
<Grid item lg= {11} md={8} xs={11}>
    <TableContainer component={Paper}>
      <Table className={classes.table} aria-label="customized table">
        <TableHead>
          <TableRow>
            <StyledTableCell align="right">Calories</StyledTableCell>
            <StyledTableCell align="right">Fat&nbsp;(g)</StyledTableCell>
            <StyledTableCell align="right">Carbs&nbsp;(g)</StyledTableCell>
            <StyledTableCell align="right">Protein&nbsp;(g)</StyledTableCell>
            <StyledTableCell align="right">Calories</StyledTableCell>
            <StyledTableCell align="right">Fat&nbsp;(g)</StyledTableCell>
            <StyledTableCell align="right">Carbs&nbsp;(g)</StyledTableCell>
            <StyledTableCell align="right">Protein&nbsp;(g)</StyledTableCell>
            <StyledTableCell align="right">Carbs&nbsp;(g)</StyledTableCell>
            <StyledTableCell align="right">Protein&nbsp;(g)</StyledTableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <StyledTableRow key={row.name}>
              <StyledTableCell component="th" scope="row">
                {row.name}
              </StyledTableCell>
           <StyledTableCell align="right"> <Link href="" id={row.id}  onClick={jojo}>   {row.id} </Link></StyledTableCell>
              <StyledTableCell align="right">{row.fat}</StyledTableCell>
              <StyledTableCell align="right">{row.carbs}</StyledTableCell>
           <StyledTableCell align="right">{row.protein}</StyledTableCell>
              <StyledTableCell align="right">{row.calories}</StyledTableCell>
              <StyledTableCell align="right">{row.fat}</StyledTableCell>
              <StyledTableCell align="right">{row.carbs}</StyledTableCell>
              <StyledTableCell align="right">{row.protein}</StyledTableCell>
              <StyledTableCell align="right">{row.carbs}</StyledTableCell>
            </StyledTableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
    </Grid>
    </Grid>
    </div>
  );
}
