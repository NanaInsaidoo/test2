import * as Yup from 'yup';
import React from 'react';


export default  [

    {
        nameOfSchool: "",
        schoolRegistrationID: ""
       

    },
    {
       
        businessRegistrationID: "G",
        primaryPhoneNumber: "H"

    }


]